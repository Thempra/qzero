#!/usr/bin/env python3
import json
import os
import shutil
import tempfile
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any
from typing import Literal

import requests
from mcp.server.fastmcp import FastMCP
from mcp.server.fastmcp.prompts.base import Prompt
from mcp.server.fastmcp.resources.types import FunctionResource
from mcp.server.fastmcp.server import Context
from mcp.shared.exceptions import McpError
from mcp.types import ErrorData
from mcp.types import INTERNAL_ERROR
from mcp.types import INVALID_PARAMS
from opentelemetry.trace.propagation import (
    get_current_span,
)
from pydantic import Field
from pydantic import ValidationError
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from semgrep import __VERSION__
from semgrep.mcp.models import CodeFile
from semgrep.mcp.models import CodePath
from semgrep.mcp.models import Finding
from semgrep.mcp.models import FindingElicitationSchema
from semgrep.mcp.models import SemgrepScanResult
from semgrep.mcp.models import WhoamiResult
from semgrep.mcp.semgrep import mk_context
from semgrep.mcp.semgrep import run_semgrep_output
from semgrep.mcp.semgrep import run_semgrep_process_sync
from semgrep.mcp.semgrep import run_semgrep_via_rpc
from semgrep.mcp.semgrep_context import SemgrepContext
from semgrep.mcp.utilities.tracing import attach_deployment_info
from semgrep.mcp.utilities.tracing import attach_findings_metrics
from semgrep.mcp.utilities.tracing import attach_oauth_info
from semgrep.mcp.utilities.tracing import attach_scan_metrics
from semgrep.mcp.utilities.tracing import start_tracing
from semgrep.mcp.utilities.tracing import with_span
from semgrep.mcp.utilities.tracing import with_tool_span
from semgrep.mcp.utilities.utils import ALLOW_SCAN_OUTSIDE_WORKSPACE_ENV_VAR
from semgrep.mcp.utilities.utils import ENCODING
from semgrep.mcp.utilities.utils import ENCODING_ERRORS
from semgrep.mcp.utilities.utils import findings_elicitation_enabled
from semgrep.mcp.utilities.utils import get_authorization_server_url
from semgrep.mcp.utilities.utils import get_current_user_from_jwt
from semgrep.mcp.utilities.utils import get_deployment_id
from semgrep.mcp.utilities.utils import get_identity
from semgrep.mcp.utilities.utils import get_oauth_authorization_server_metadata
from semgrep.mcp.utilities.utils import get_semgrep_access_token
from semgrep.mcp.utilities.utils import get_semgrep_api_url
from semgrep.mcp.utilities.utils import get_semgrep_app_token
from semgrep.mcp.utilities.utils import get_workspace_dir
from semgrep.mcp.utilities.utils import is_hosted
from semgrep.mcp.utilities.utils import is_oauth_authenticated
from semgrep.mcp.utilities.utils import re_identity_string
from semgrep.mcp.utilities.utils import scan_outside_workspace_allowed
from semgrep.metrics import Finding as MetricsFinding
from semgrep.semgrep_interfaces.semgrep_output_v1 import CliOutput
from semgrep.state import get_state
from semgrep.verbose_logging import getLogger

logger = getLogger(__name__)

# ---------------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------------

# Field definitions for scan tools
REMOTE_CODE_FILES_FIELD = Field(
    description="List of dictionaries with 'path' and 'content' keys"
)
LOCAL_CODE_FILES_FIELD = Field(
    description=(
        "List of dictionaries with 'path' pointing to the absolute path of the code file. "
        "Every path must be inside the workspace."
    )
)

CONFIG_FIELD = Field(
    description="Optional Semgrep configuration string (e.g. 'p/docker', 'p/xss', 'auto')",
    default=None,
)

RULE_FIELD = Field(description="Semgrep YAML rule string")
RULE_ID_FIELD = Field(description="Semgrep rule ID")

CODE_FIELD = Field(description="The code to get the AST for")
LANGUAGE_FIELD = Field(description="The programming language of the code")

# Field defintions for findings tool
ISSUE_TYPE_DEFAULT: Literal["ISSUE_TYPE_SAST"] = "ISSUE_TYPE_SAST"
ISSUE_TYPE_FIELD = Field(
    default=ISSUE_TYPE_DEFAULT, description="Type of issue to filter by."
)
REPOS_FIELD: list[str] = Field(
    default=[],
    description="List of repository names to filter by. Include the owner and repository name, e.g. 'owner/repository'",
)
STATUS_DEFAULT: Literal["ISSUE_TAB_OPEN"] = "ISSUE_TAB_OPEN"
STATUS_FIELD = Field(
    default=STATUS_DEFAULT, description="Status of the issue to filter by."
)
SEVERITIES_FIELD = Field(
    default=None, description="Severities of the issues to filter by."
)
CONFIDENCE_FIELD = Field(
    default=None, description="Confidences of the issues to filter by."
)
AUTOTRIAGE_VERDICT_FIELD = Field(
    default=None,
    description="Autotriage verdict of the issues to filter by. If not provided, findings with any verdict (including unrated) are returned.",
)
REFS_FIELD: list[str] = Field(
    default=[],
    description="List of git refs (branch names) to filter findings by. If not provided, only findings on the primary branch are returned.",
)
LIMIT_FIELD = Field(default=10, description="Maximum number of findings to return")

MCP_AGENT_TAG = "(command/mcp)"


def _build_findings_filter(
    *,
    status: str,
    repos: list[str],
    severities: list[
        Literal["SEVERITY_CRITICAL", "SEVERITY_HIGH", "SEVERITY_MEDIUM", "SEVERITY_LOW"]
    ]
    | None,
    confidence: list[Literal["CONFIDENCE_HIGH", "CONFIDENCE_MEDIUM", "CONFIDENCE_LOW"]]
    | None,
    autotriage_verdict: Literal["VERDICT_TRUE_POSITIVE", "VERDICT_FALSE_POSITIVE"]
    | None,
    refs: list[str],
) -> dict[str, Any]:
    """Build the `filter` payload for the findings API.

    The endpoint requires either a `refs` list or `on_primary_branch=True`; we set
    `on_primary_branch` only when no refs are provided. `aiVerdicts` is empty when
    no `autotriage_verdict` is given so unrated findings are not filtered out.
    """
    filter_body: dict[str, Any] = {
        "status": [status],
        "repositoryNames": repos,
        "severities": severities if severities else [],
        "confidences": confidence if confidence else [],
        "aiVerdicts": [autotriage_verdict] if autotriage_verdict else [],
    }
    if refs:
        filter_body["refs"] = refs
    else:
        filter_body["on_primary_branch"] = True
    return filter_body


# ---------------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------------


def safe_join(base_dir: str, untrusted_path: str) -> str:
    """
    Joins a base directory with an untrusted relative path and ensures the final path
    doesn't escape the base directory.

    Args:
        base_dir: The base directory to join the untrusted path to
        untrusted_path: The untrusted relative path to join to the base directory
    """
    # Absolute, normalized path to the base directory
    base_path = Path(base_dir).resolve()

    # Handle empty path, current directory, or paths with only slashes
    if not untrusted_path or untrusted_path == "." or untrusted_path.strip("/") == "":
        return base_path.as_posix()

    # Ensure untrusted path is not absolute
    # This is soft validation, path traversal is checked later
    if Path(untrusted_path).is_absolute():
        raise ValueError("Untrusted path must be relative")

    # Join and normalize the untrusted path
    full_path = base_path / Path(untrusted_path)

    # Ensure the final path doesn't escape the base directory
    if not full_path == full_path.resolve():
        raise ValueError(
            f"Untrusted path escapes the base directory!: {untrusted_path}"
        )

    return full_path.as_posix()


# Path validation
def cwd_workspace_dir() -> str | None:
    """
    The server's working directory, used as the workspace when the client
    reports no root: Claude Code starts a stdio server in the project
    directory. None when it is the home directory or contains it, such as
    the filesystem root, since that would put ~/.ssh in scope.
    """
    cwd = Path.cwd().resolve()
    if Path.home().resolve().is_relative_to(cwd):
        return None
    return cwd.as_posix()


def resolve_within_workspace(path: str, workspace_dir: str) -> str:
    """
    Resolves an absolute path, and returns it only if it is inside the
    workspace. Symlinks are followed first, so a link inside the workspace
    that points out of it is rejected.

    Raises:
        ValueError: If the path is outside the workspace
    """
    resolved = Path(path).resolve()
    root = Path(workspace_dir).resolve()
    if not resolved.is_relative_to(root):
        raise ValueError(f"{path} is outside the workspace")
    return safe_join(root.as_posix(), resolved.relative_to(root).as_posix())


def validate_absolute_path(path_to_validate: str, param_name: str) -> str:
    """Validates an absolute path to ensure it's safe to use"""
    if not Path(path_to_validate).is_absolute():
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message=f"{param_name} must be an absolute path. Received: {path_to_validate}",
            )
        )

    # Normalize path and ensure no path traversal is possible
    normalized_path = os.path.normpath(path_to_validate)

    # Check if normalized path is still absolute
    if not Path(normalized_path).resolve() == Path(normalized_path):
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message=f"{param_name} contains invalid path traversal sequences",
            )
        )

    return normalized_path


def validate_config(config: str | None = None) -> str:
    """Validates semgrep configuration parameter"""
    # Allow registry references (p/ci, p/security, etc.)
    if (
        config is None
        or config.startswith("p/")
        or config.startswith("r/")
        or config == "auto"
    ):
        return config or ""
    # Otherwise, treat as path and validate
    return validate_absolute_path(config, "config")


# Utility functions for handling code content
def create_temp_files_from_code_content(code_files: list[CodeFile]) -> str:
    """
    Creates temporary files from code content

    Args:
        code_files: List of CodeFile objects

    Returns:
        Path to temporary directory containing the files

    Raises:
        McpError: If there are issues creating or writing to files
    """
    temp_dir = None

    try:
        # Create a temporary directory
        temp_dir = tempfile.mkdtemp(prefix="semgrep_scan_")

        # Create files in the temporary directory
        for file_info in code_files:
            filename = file_info.path
            if not filename:
                continue

            temp_file_path = safe_join(temp_dir, filename)

            try:
                # Create subdirectories if needed
                os.makedirs(os.path.dirname(temp_file_path), exist_ok=True)

                # Write content to file
                with open(temp_file_path, "w", encoding=ENCODING) as f:
                    f.write(file_info.content)
            except OSError as e:
                raise McpError(
                    ErrorData(
                        code=INTERNAL_ERROR,
                        message=f"Failed to create or write to file {filename}: {e!s}",
                    )
                ) from e

        return temp_dir
    except Exception as e:
        if temp_dir:
            # Clean up temp directory if creation failed
            shutil.rmtree(temp_dir, ignore_errors=True)
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Failed to create temporary files: {e!s}"
            )
        ) from e


def get_semgrep_scan_args(temp_dir: str, config: str | None = None) -> list[str]:
    """
    Builds command arguments for semgrep scan

    Args:
        temp_dir: Path to temporary directory containing the files
        config: Optional Semgrep configuration (e.g. "auto" or absolute path to rule file)

    Returns:
        List of command arguments
    """

    # Build command arguments and just run semgrep scan
    # if no config is provided to allow for either the default "auto"
    # or whatever the logged in config is
    args = ["scan", "--json", "--experimental"]  # avoid the extra exec
    args.extend(["--x-mcp"])
    if config:
        args.extend(["--config", config])

    # If the config is auto and metrics are off, raise an error. This
    # should only happen if the user is calling the MCP scan tool without
    # a config with metrics turned off. Hooks are not affected
    # since we pass in the config "hooks" for the hooks.
    if (config is None or config == "auto") and (
        (os.environ.get("SEMGREP_SEND_METRICS") or "").lower() in ("off", "0", "false")
    ):
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message="Cannot run scan with auto config when metrics are off. Please allow metrics or run with a specific config.",
            )
        )

    args.append(temp_dir)
    return args


def validate_local_files(
    local_files: list[CodePath], workspace_dir: str | None
) -> list[CodeFile]:
    """
    Validates the local_files parameter for semgrep scan using Pydantic validation.
    Only files inside the workspace are read, unless scanning outside it has
    been opted into.

    Args:
        local_files: List of singleton dictionaries with a "path" key
        workspace_dir: The client's workspace root. When empty, the server's
            working directory is used instead (see cwd_workspace_dir).

    Raises:
        McpError: If validation fails
    """
    if not local_files:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message="local_files must be a non-empty list of file objects",
            )
        )
    allow_outside = scan_outside_workspace_allowed()
    if not workspace_dir:
        workspace_dir = cwd_workspace_dir()
    if not allow_outside and not workspace_dir:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message=(
                    "semgrep_scan only reads files inside the workspace, but could not tell where the "
                    "workspace is: the MCP client reported no workspace root, and the server was started "
                    f"in {Path.cwd()}, which is the home directory or contains it. This usually means the "
                    "Semgrep MCP server is configured at user level (e.g. ~/.cursor/mcp.json), where it is "
                    "shared across projects. To fix it, do one of: configure the server per project so it "
                    "is started in the project directory; use an MCP client that reports workspace roots; "
                    f"or set {ALLOW_SCAN_OUTSIDE_WORKSPACE_ENV_VAR}=true in the server's environment, which "
                    "turns off this check and lets it read any path."
                ),
            )
        )
    try:
        # Pydantic will automatically validate each item in the list
        validated_local_files = []
        for file in local_files:
            path = file.path
            if not Path(path).is_absolute():
                raise McpError(
                    ErrorData(
                        code=INVALID_PARAMS,
                        message="code_files.path must be a absolute path",
                    )
                )
            # Checked before anything is read: the path comes from the model,
            # and a prompt-injected one can name any file the user can read.
            read_path = (
                path
                if allow_outside or workspace_dir is None
                else resolve_within_workspace(path, workspace_dir)
            )
            contents = Path(read_path).read_text(
                encoding=ENCODING, errors=ENCODING_ERRORS
            )
            # We need to not use the absolute path here, as there is logic later
            # that raises, to prevent path traversal.
            # In reality, the name of the file is pretty immaterial. We only
            # want the accurate path insofar as we can get the contents (whcih we do here)
            # and so we can remember what original file it corresponds to.
            # Taking the name of the file should be enough.
            validated_local_files.append(
                CodeFile(path=Path(path).name, content=contents)
            )
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS, message=f"Invalid local code files format: {e!s}"
            )
        ) from e

    return validated_local_files


def validate_remote_files(code_files: list[CodeFile]) -> list[CodeFile]:
    """
    Validates the code_files parameter for semgrep scan using Pydantic validation

    Args:
        code_files: List of dictionaries with a "path" and "content" key

    Raises:
        McpError: If validation fails
    """
    if not code_files:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message="code_files must be a non-empty list of file objects",
            )
        )
    try:
        # Pydantic will automatically validate each item in the list
        validated_code_files = [CodeFile.model_validate(file) for file in code_files]

        return validated_code_files
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS, message=f"Invalid remote code files format: {e!s}"
            )
        ) from e


def remove_temp_dir_from_results(results: SemgrepScanResult, temp_dir: str) -> None:
    """
    Clean the results from semgrep by converting temporary file paths back to
    original relative paths

    Args:
        results: SemgrepScanResult object containing semgrep results
        temp_dir: Path to temporary directory used for scanning
    """
    # Process findings results
    for finding in results.results:
        if "path" in finding:
            try:
                finding["path"] = os.path.relpath(finding["path"], temp_dir)
            except ValueError:
                # Skip if path is not relative to temp_dir
                continue

    # Process scanned paths
    if "scanned" in results.paths:
        results.paths["scanned"] = [
            os.path.relpath(path, temp_dir) for path in results.paths["scanned"]
        ]

    if "skipped" in results.paths:
        results.paths["skipped"] = [
            os.path.relpath(path, temp_dir) for path in results.paths["skipped"]
        ]


async def finding_elicitation(
    ctx: Context, results: SemgrepScanResult
) -> tuple[
    list[tuple[str, MetricsFinding]],
    list[tuple[str, MetricsFinding]],
    list[tuple[str, MetricsFinding]],
]:
    """
    Elicit user input for findings to determine if they are true positives or false positives.
    If findings elicitation is not enabled, throws an error.

    Args:
        ctx: Context object
        results: SemgrepScanResult object

    Returns:
        Tuple of lists of true positive (first item), false positive (second item), and skipped (third item) findings
    """
    with with_span(get_current_span(), "finding_elicitation") as _:
        findings = get_state().metrics.cli_matches_to_findings(results.results)
        if not findings_elicitation_enabled():
            raise McpError(
                ErrorData(
                    code=INVALID_PARAMS,
                    message="Findings elicitation is not enabled.",
                )
            )

        true_positive_findings, false_positive_findings, skipped_findings = [], [], []
        logger.info(f"Findings to elicit: {findings}")
        for rule_id, finding in findings:
            result = await ctx.elicit(
                message=f"🔍 Semgrep Finding Detected: [{finding.severity}] {rule_id} ({finding.path}:{finding.line}:{finding.col})",
                schema=FindingElicitationSchema,
            )
            if result.action == "accept" and result.data:
                if result.data.true_positive:
                    logger.info(f"Finding {finding} is a true positive.")
                    true_positive_findings.append((rule_id, finding))
                elif result.data.false_positive:
                    logger.info(f"Finding {finding} is a false positive.")
                    false_positive_findings.append((rule_id, finding))
                elif result.data.skip:
                    logger.info(f"Finding {finding} is a skip.")
                    skipped_findings.append((rule_id, finding))

        return true_positive_findings, false_positive_findings, skipped_findings


# ---------------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------------


@asynccontextmanager
async def server_lifespan(_server: FastMCP) -> AsyncIterator[SemgrepContext]:
    """Manage server startup and shutdown lifecycle."""
    # Initialize resources on startup with tracing
    # MCP requires Pro Engine
    with start_tracing("mcp-python-server") as span:
        context = await mk_context(top_level_span=span)
        attach_deployment_info(span)
        attach_oauth_info(span, context)
        try:
            yield context
        finally:
            context.shutdown()


# ---------------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------------


@with_tool_span(is_semgrep_scan=False)
async def semgrep_rule_schema(ctx: Context) -> str:
    """
    Get the schema for a Semgrep rule

    Use this tool when you need to:
      - get the schema required to write a Semgrep rule
      - need to see what fields are available for a Semgrep rule
      - verify what fields are available for a Semgrep rule
      - verify the syntax for a Semgrep rule is correct
    """
    try:
        response = requests.get(
            f"{(get_semgrep_api_url())}/schema_url", timeout=(2, 30)
        )
        response.raise_for_status()
        data: dict[str, str] = response.json()
        schema_url: str = data["schema_url"]
        response = requests.get(schema_url, timeout=(2, 30))
        response.raise_for_status()
        return str(response.text)
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR,
                message=f"Error getting schema for Semgrep rule: {e!s}",
            )
        ) from e


@with_tool_span(is_semgrep_scan=False)
async def get_supported_languages(ctx: Context) -> list[str]:
    """
    Returns a list of supported languages by Semgrep

    Only use this tool if you are not sure what languages Semgrep supports.
    """
    args = ["show", "supported-languages", "--experimental"]

    # Parse output and return list of languages
    languages = await run_semgrep_output(top_level_span=None, args=args)
    return [lang.strip() for lang in languages.strip().split("\n") if lang.strip()]


async def get_deployment_slug() -> str:
    """
    Fetches and caches the deployment slug from Semgrep API.
    Only works with API tokens (not JWTs).

    Returns:
        str: The deployment slug

    Raises:
        McpError: If unable to fetch deployments or no deployments found
    """

    # Get API token
    api_token = get_semgrep_app_token()
    if not api_token:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message="""
                  SEMGREP_APP_TOKEN environment variable must be set or user
                  must be logged in to use this tool
                """,
            )
        )

    # Fetch deployments
    url = f"{get_semgrep_api_url()}/v1/deployments"
    headers = {"Authorization": f"Bearer {api_token}", "Accept": "application/json"}

    try:
        response = requests.get(url, headers=headers, timeout=(2, 30))
        response.raise_for_status()
        data = response.json()

        # Extract deployment slug - assuming we want the first deployment
        deployments = data.get("deployments", [])
        if not deployments or not deployments[0].get("slug"):
            raise McpError(
                ErrorData(
                    code=INTERNAL_ERROR,
                    message="No deployments found for this API token",
                )
            )

        return str(deployments[0]["slug"])

    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            raise McpError(
                ErrorData(
                    code=INVALID_PARAMS,
                    message="Invalid API token: check your SEMGREP_APP_TOKEN environment variable.",
                )
            ) from e
        else:
            raise McpError(
                ErrorData(
                    code=INTERNAL_ERROR,
                    message=f"Error fetching deployments: {e.response.text}",
                )
            ) from e
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR,
                message=f"Error fetching deployments from Semgrep: {e!s}",
            )
        ) from e


@with_tool_span(is_semgrep_scan=False)
async def semgrep_findings(
    ctx: Context,
    issue_type: Literal["ISSUE_TYPE_SAST", "ISSUE_TYPE_SCA"] = ISSUE_TYPE_FIELD,
    repos: list[str] = REPOS_FIELD,
    status: Literal[
        "ISSUE_TAB_OPEN",
        "ISSUE_TAB_CLOSED",
        "ISSUE_TAB_IGNORED",
        "ISSUE_TAB_REVIEWING",
        "ISSUE_TAB_FIXING",
    ] = STATUS_FIELD,
    severities: list[
        Literal["SEVERITY_CRITICAL", "SEVERITY_HIGH", "SEVERITY_MEDIUM", "SEVERITY_LOW"]
    ]
    | None = SEVERITIES_FIELD,
    confidence: list[Literal["CONFIDENCE_HIGH", "CONFIDENCE_MEDIUM", "CONFIDENCE_LOW"]]
    | None = CONFIDENCE_FIELD,
    autotriage_verdict: Literal["VERDICT_TRUE_POSITIVE", "VERDICT_FALSE_POSITIVE"]
    | None = AUTOTRIAGE_VERDICT_FIELD,
    refs: list[str] = REFS_FIELD,
    limit: int = LIMIT_FIELD,
) -> list[Finding] | str:
    """
    Fetches findings from the Semgrep AppSec Platform Findings API.

    This function retrieves security, code quality, and supply chain findings that have already been
    identified by previous Semgrep scans and uploaded to the Semgrep AppSec platform. It does NOT
    perform a new scan or analyze code directly. Instead, it queries the Semgrep API to access
    historical scan results for a given repository or set of repositories.

    DEFAULT BEHAVIOR: By default, this tool should filter by the current repository. The model
    should determine the current repository name and pass it in the 'repos' parameter to ensure
    findings are scoped to the relevant codebase. However, users may explicitly request findings
    from other repositories, in which case the model should respect that request.

    Use this function when a prompt requests a summary, list, or analysis of existing findings,
    such as:
        - "Please list the top 10 security findings and propose solutions for them."
        - "Show all open critical vulnerabilities in this repository."
        - "Summarize the most recent Semgrep scan results."
        - "Get findings from repository X" (explicitly requesting different repo)

    This function is ideal for:
    - Reviewing, listing, or summarizing findings from past scans.
    - Providing actionable insights or remediation advice based on existing scan data.

    Do NOT use this function to perform a new scan or check code that has not yet been analyzed by
    Semgrep. For new scans, use the appropriate scanning function.
    """
    token = get_semgrep_app_token()

    if is_oauth_authenticated():
        token = get_semgrep_access_token()
    else:
        # Check whether the token has the `webapi` role for API tokens
        identity = await get_identity()
        match = re_identity_string.search(identity["identity"])
        if match is None:
            logger.error("Identity string in unexpected format")
        else:
            inner = match.group(1)
            if "webapi" not in inner:
                raise McpError(
                    ErrorData(
                        code=INVALID_PARAMS,
                        message="Cannot access findings without token with `webapi` role: you should generate one manually from semgrep.dev",
                    )
                )

    deployment_id = get_deployment_id()

    if deployment_id is None:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message="No deployment ID found. User must be authenticated to use this tool.",
            )
        )

    if len(repos) == 0:
        raise McpError(
            ErrorData(
                code=INVALID_PARAMS,
                message="No repositories provided. User must provide at least one repository to filter by.",
            )
        )

    url = f"{get_semgrep_api_url()}/agent/deployments/{deployment_id}/issues/v2"
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    request_body = {
        "deploymentId": str(deployment_id),
        "issueType": issue_type,
        "filter": _build_findings_filter(
            status=status,
            repos=repos,
            severities=severities,
            confidence=confidence,
            autotriage_verdict=autotriage_verdict,
            refs=refs,
        ),
        "limit": limit,
    }
    try:
        logger.info(f"Request body: {request_body}")
        response = requests.post(
            url,
            headers=headers,
            json=request_body,
            timeout=(
                2,
                120,
            ),  # Longer timeout for this endpoint because it is known that a longer timeout is needed for a higher limit.
        )
        response.raise_for_status()
        data = response.json()

        issues = data.get("issues", [])
        logger.info(f"Found {len(issues)} findings")
        if issues is None or len(issues) == 0:
            return "No findings found"  # Returning an empty list confuses the agent, so we return a string to indicate that no findings were found.
        return [Finding.model_validate(issue["issue"]) for issue in issues]
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 401:
            raise e
        elif e.response.status_code == 404:
            raise McpError(
                ErrorData(
                    code=INVALID_PARAMS,
                    message=f"Deployment {deployment_id} not found or you don't have access to it.",
                )
            ) from e
        else:
            raise McpError(
                ErrorData(
                    code=INTERNAL_ERROR,
                    message=f"Error fetching findings: {e.response.text}. Try reducing the limit parameter.",  # It is known that if the limit is too high, the tool will timeout.
                )
            ) from e
    except ValidationError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error parsing semgrep output: {e!s}"
            )
        ) from e
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR,
                message=f"Error fetching findings from Semgrep: {e!s}. Try reducing the limit parameter.",  # It is known that if the limit is too high, the tool will timeout.
            )
        ) from e


@with_tool_span()
async def semgrep_scan_with_custom_rule(
    ctx: Context,
    code_files: list[CodeFile] = REMOTE_CODE_FILES_FIELD,
    rule: str = RULE_FIELD,
) -> SemgrepScanResult:
    """
    Runs a Semgrep scan with a custom rule on provided code content
    and returns the findings in JSON format

    Use this tool when you need to:
      - scan code files for specific security vulnerability not covered by the default Semgrep rules
      - scan code files for specific issue not covered by the default Semgrep rules
    """

    workspace_dir = await get_workspace_dir(ctx)

    # Validate code_files
    validated_code_files = validate_remote_files(code_files)
    temp_dir = None
    try:
        # Create temporary files from code content
        temp_dir = create_temp_files_from_code_content(validated_code_files)
        # Write rule to file
        rule_file_path = os.path.join(temp_dir, "rule.yaml")
        with open(rule_file_path, "w", encoding=ENCODING) as f:
            f.write(rule)

        # Run semgrep scan with custom rule
        args = get_semgrep_scan_args(temp_dir, rule_file_path)
        output = await run_semgrep_output(top_level_span=None, args=args)
        results: SemgrepScanResult = SemgrepScanResult.model_validate_json(output)

        if findings_elicitation_enabled():
            tps, fps, skips = await finding_elicitation(ctx, results)
            attach_findings_metrics(get_current_span(), tps, fps, skips)
        else:
            logger.info("Findings elicitation is not enabled, skipping.")

        attach_scan_metrics(
            get_current_span(), results, workspace_dir, validated_code_files
        )

        remove_temp_dir_from_results(results, temp_dir)
        return results

    except McpError as e:
        raise e
    except ValidationError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error parsing semgrep output: {e!s}"
            )
        ) from e
    except Exception as e:
        raise McpError(
            ErrorData(code=INTERNAL_ERROR, message=f"Error running semgrep scan: {e!s}")
        ) from e

    finally:
        if temp_dir:
            # Clean up temporary files
            shutil.rmtree(temp_dir, ignore_errors=True)


@with_tool_span(is_semgrep_scan=False)
async def get_abstract_syntax_tree(
    ctx: Context,
    code: str = CODE_FIELD,
    language: str = LANGUAGE_FIELD,
) -> str:
    """
    Returns the Abstract Syntax Tree (AST) for the provided code file in JSON format

    Use this tool when you need to:
      - get the Abstract Syntax Tree (AST) for the provided code file\
      - get the AST of a file
      - understand the structure of the code in a more granular way
      - see what a parser sees in the code
    """
    temp_dir = None
    temp_file_path = ""
    try:
        # Create temporary directory and file for AST generation
        temp_dir = tempfile.mkdtemp(prefix="semgrep_ast_")
        temp_file_path = os.path.join(temp_dir, "code.txt")  # safe

        # Write content to file
        with open(temp_file_path, "w", encoding=ENCODING) as f:
            f.write(code)

        args = [
            "--experimental",
            "--dump-ast",
            "-l",
            language,
            "--json",
            temp_file_path,
        ]
        return await run_semgrep_output(top_level_span=None, args=args)

    except McpError as e:
        raise e
    except ValidationError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error parsing semgrep output: {e!s}"
            )
        ) from e
    except OSError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR,
                message=f"Failed to create or write to file {temp_file_path}: {e!s}",
            )
        ) from e
    except Exception as e:
        raise McpError(
            ErrorData(code=INTERNAL_ERROR, message=f"Error running semgrep scan: {e!s}")
        ) from e
    finally:
        if temp_dir:
            # Clean up temporary files
            shutil.rmtree(temp_dir, ignore_errors=True)


# ---------------------------------------------------------------------------------
# Supply Chain scanning
# ---------------------------------------------------------------------------------


async def semgrep_scan_sca(
    context: SemgrepContext,
    workspace_dir: str,
) -> CliOutput:
    cwd = os.getcwd()

    # Do this from the repo so we only scan stuff in there
    os.chdir(workspace_dir)
    args = ["scan", "--config", "supply-chain", "--json", "--x-mcp"]
    output = await run_semgrep_process_sync(context.top_level_span, args)
    os.chdir(cwd)

    resp_json = json.loads(output.stdout.decode())

    return CliOutput.from_json(resp_json)


@with_tool_span()
async def semgrep_scan_supply_chain(
    ctx: Context,
) -> CliOutput:
    """
    Runs a Semgrep supply chain scan on the provided workspace directory,
    to identify potential third-party security vulnerabilities.

    Use this tool when you:
      - change the version of a dependency in a project
      - add a new dependency to a project
      - update the lockfiles of a project
    """

    context: SemgrepContext = ctx.request_context.lifespan_context
    workspace_dir = await get_workspace_dir(ctx)
    if workspace_dir is None:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR,
                message="Workspace directory not found",
            )
        )

    try:
        if context.process is None:
            raise McpError(
                ErrorData(
                    code=INTERNAL_ERROR,
                    message="Supply Chain scan requires an active Semgrep daemon to be running.",
                )
            )
        else:
            logger.info(f"Running Supply Chain scan on path: {workspace_dir}")
            return await semgrep_scan_sca(context, workspace_dir)
    except McpError as e:
        raise e
    except ValidationError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error parsing semgrep output: {e!s}"
            )
        ) from e
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR,
                message=f"Error running semgrep scan (supply chain): {e!s}",
            )
        ) from e


# ---------------------------------------------------------------------------------
# Scanning tools
# ---------------------------------------------------------------------------------


@with_tool_span()
async def semgrep_scan_cli(
    ctx: Context,
    workspace_dir: str | None,
    code_files: list[CodeFile],
) -> SemgrepScanResult:
    """
    Runs a Semgrep scan on provided code content and returns the findings in JSON format

    Depending on whether `USE_SEMGREP_RPC` is set, this tool will either run a `pysemgrep`
    CLI scan, or an RPC-based scan.

    Respectively, this will cause us to return either a `SemgrepScanResult` or a `CliOutput`.

    Use this tool when you need to:
      - scan code files for security vulnerabilities
      - scan code files for other issues
    """

    temp_dir = None
    try:
        # Create temporary files from code content
        temp_dir = create_temp_files_from_code_content(code_files)
        args = get_semgrep_scan_args(temp_dir, None)
        output = await run_semgrep_output(top_level_span=None, args=args)
        results: SemgrepScanResult = SemgrepScanResult.model_validate_json(output)
        remove_temp_dir_from_results(results, temp_dir)

        if findings_elicitation_enabled():
            tps, fps, skips = await finding_elicitation(ctx, results)
            attach_findings_metrics(get_current_span(), tps, fps, skips)
        else:
            logger.info("Findings elicitation is not enabled, skipping.")

        attach_scan_metrics(get_current_span(), results, workspace_dir, code_files)

        return results

    except McpError as e:
        raise e
    except ValidationError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error parsing semgrep output: {e!s}"
            )
        ) from e
    except Exception as e:
        raise McpError(
            ErrorData(code=INTERNAL_ERROR, message=f"Error running semgrep scan: {e!s}")
        ) from e

    finally:
        if temp_dir:
            # Clean up temporary files
            shutil.rmtree(temp_dir, ignore_errors=True)


@with_tool_span(
    send_metrics=False
)  # Don't send metrics for this because we send metrics for each RPC call from the daemon
async def semgrep_scan_rpc(
    ctx: Context,
    workspace_dir: str | None,
    code_files: list[CodeFile],
) -> SemgrepScanResult:
    """
    Runs a Semgrep scan on provided code content using the new Semgrep RPC feature.

    This should run much faster than the comparative `semgrep_scan` tool.
    """

    temp_dir = None
    try:
        # TODO: perhaps should return more interpretable results?
        context: SemgrepContext = ctx.request_context.lifespan_context
        results = await run_semgrep_via_rpc(context, workspace_dir, code_files)

        if findings_elicitation_enabled():
            tps, fps, skips = await finding_elicitation(ctx, results)
            attach_findings_metrics(get_current_span(), tps, fps, skips)
        else:
            logger.info("Findings elicitation is not enabled, skipping.")

        attach_scan_metrics(get_current_span(), results, workspace_dir, code_files)

        return results
    except McpError as e:
        raise e
    except ValidationError as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error parsing semgrep output: {e!s}"
            )
        ) from e
    except Exception as e:
        raise McpError(
            ErrorData(code=INTERNAL_ERROR, message=f"Error running semgrep scan: {e!s}")
        ) from e

    finally:
        if temp_dir:
            # Clean up temporary files
            shutil.rmtree(temp_dir, ignore_errors=True)


async def semgrep_scan_core(
    ctx: Context,
    workspace_dir: str | None,
    code_files: list[CodeFile],
) -> SemgrepScanResult:
    """
    Runs a Semgrep scan on provided CodeFile objects and returns the findings in JSON format

    Depending on whether `USE_SEMGREP_RPC` is set, this tool will either run a `pysemgrep`
    CLI scan, or an RPC-based scan.

    Respectively, this will cause us to return either a `SemgrepScanResult` or a `CliOutput`.
    """

    context: SemgrepContext = ctx.request_context.lifespan_context

    paths = [cf.path for cf in code_files]

    if context.process is not None:
        logger.info(f"Running RPC-based scan on paths: {paths}")
        return await semgrep_scan_rpc(ctx, workspace_dir, code_files)
    else:
        logger.info(f"Running CLI-based scan on paths: {paths}")
        return await semgrep_scan_cli(ctx, workspace_dir, code_files)


@with_tool_span()
async def semgrep_scan_remote(
    ctx: Context,
    code_files: list[CodeFile] = REMOTE_CODE_FILES_FIELD,
) -> SemgrepScanResult:
    """
    Runs a Semgrep scan on provided code content and returns the findings in JSON format

    Use this tool when you need to:
      - scan code files for security vulnerabilities
      - scan code files for other issues
    """

    # Implementer's note:
    # This is one possible entry point for regular scanning, depending on whether
    # the server is remotely hosted or not.
    # If the server is hosted, only this tool will be available, and not the
    # `semgrep_scan` tool.

    validated_code_files = validate_remote_files(code_files)

    return await semgrep_scan_core(ctx, None, validated_code_files)


@with_tool_span(
    send_metrics=False
)  # Don't send metrics for this because it is a wrapper for either the rpc scan or the cli scan
async def semgrep_scan(
    ctx: Context,
    code_files: list[CodePath] = LOCAL_CODE_FILES_FIELD,
) -> SemgrepScanResult:
    """
    Runs a Semgrep scan locally on provided code files returns the findings in JSON format.

    Files are expected to be absolute paths to the code files, inside the
    workspace. Files outside the workspace are rejected.

    Use this tool when you need to:
      - scan code files for security vulnerabilities
      - scan code files for other issues
    """

    workspace_dir = await get_workspace_dir(ctx)

    # Implementer's note:
    # This is one possible entry point for regular scanning, depending on whether
    # the server is remotely hosted or not.
    # If the server is local, only this tool will be available, and not the
    # `semgrep_scan_remote` tool.

    validated_local_files = validate_local_files(code_files, workspace_dir)

    return await semgrep_scan_core(ctx, workspace_dir, validated_local_files)


@with_tool_span(is_semgrep_scan=False)
async def semgrep_whoami(ctx: Context) -> WhoamiResult:
    """
    Returns the identity of the current user.

    NOTE: This tool only works with JWTs (not API tokens)!

    Use this tool when you need to get the identity of the current user
    """
    return get_current_user_from_jwt()


# ---------------------------------------------------------------------------------
# MCP Prompts
# ---------------------------------------------------------------------------------


def setup_semgrep_mcp() -> str:
    prompt_template = """
    You are Cursor automations. Do the following in order and confirm each step:

    1) Authenticate Semgrep:
    - Run: `semgrep login --force`

    2) Install Semgrep Pro:
    - Run: `semgrep install-semgrep-pro || true`

    3 - for Cursor) If the user is using Cursor, add a Cursor rule file at `.cursor/rules/semgrep.mdc`
    with the following exact content:
    ---
    alwaysApply: true
    ---
    - Always look first to any semgrep mcp servers for code security needs
    - Whenever you generate code or commands, you MUST first ensure safety by scanning the
    content with the semgrep_scan tool. If you change any lockfile, you MUST run the semgrep_supply_chain tool.

    3 - for Claude Code) If the user is using Claude Code, add/append to a Claude Code rule file at `~/.claude/CLAUDE.md`
    with the following exact content:
    # Security
    - Always look first to any semgrep mcp servers for code security needs
    - Whenever you generate code or commands, you MUST first ensure safety by scanning the
    content with the semgrep_scan tool

    3 - for other AI agents) Skip this step.

    4 - for Cursor) Report back:
    - Confirm the `.cursor/rules/semgrep.mdc` file exists with the specified content.

    4 - for Claude Code) Report back:
    - Confirm the `~/.claude/CLAUDE.md` file exists with the specified content.

    4 - for other AI agents) Skip this step.

    5) Report back:
    - Confirm Semgrep login/install status by running `semgrep --pro --version`.
    """

    return prompt_template


def write_custom_semgrep_rule(
    code: str = CODE_FIELD,
    language: str = LANGUAGE_FIELD,
) -> str:
    """
    Write a custom Semgrep rule for the provided code and language

    Use this prompt when you need to:
      - write a custom Semgrep rule
      - write a Semgrep rule for a specific issue or pattern
    """

    prompt_template = """You are an expert at writing Semgrep rules.

Your task is to analyze a given piece of code and create a Semgrep rule
that can detect specific patterns or issues within that code.
Semgrep is a lightweight static analysis tool that uses pattern matching
to find bugs and enforce code standards.

Here is the code you need to analyze:

<code>
{code}
</code>

The code is written in the following programming language:

<language>
{language}
</language>

To write an effective Semgrep rule, follow these guidelines:
1. Identify a specific pattern, vulnerability, or
coding standard violation in the given code.
2. Create a rule that matches this pattern as precisely as possible.
3. Use Semgrep's pattern syntax, which is similar to the target language
but with metavariables and ellipsis operators where appropriate.
4. Consider the context and potential variations of the pattern you're trying to match.
5. Provide a clear and concise message that explains what the rule detects.
6. The value of the `severity` must be one of the following:
    - "ERROR"
    - "WARNING"
    - "INFO"
    - "INVENTORY"
    - "EXPERIMENT"
    - "CRITICAL"
    - "HIGH"
    - "MEDIUM"
    - "LOW"

7. The value of the `languages` must be a list of languages that the rule is applicable
to and include the language given in <language> tags.


Write your Semgrep rule in YAML format. The rule should include at least the following keys:
- rules
- id
- pattern
- message
- severity
- languages

Before providing the rule, briefly explain in a few sentences what specific issue or
pattern your rule is designed to detect and why it's important.

Then, output your Semgrep rule inside <semgrep_rule> tags.

Ensure that the rule is properly formatted in YAML.
Make sure to include all the required keys and values in the rule."""

    return prompt_template.format(code=code, language=language)


# ---------------------------------------------------------------------------------
# MCP Resources
# ---------------------------------------------------------------------------------


async def get_semgrep_rule_schema() -> str:
    """Specification of the Semgrep rule YAML syntax using JSON schema."""

    schema_url = "https://raw.githubusercontent.com/semgrep/semgrep-interfaces/refs/heads/main/rule_schema_v1.yaml"
    try:
        response = requests.get(schema_url, timeout=(2, 30))
        response.raise_for_status()
        return str(response.text)
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error loading Semgrep rule schema: {e!s}"
            )
        ) from e


async def get_semgrep_rule_yaml(rule_id: str = RULE_ID_FIELD) -> str:
    """Full Semgrep rule in YAML format from the Semgrep registry."""

    try:
        response = requests.get(f"https://semgrep.dev/c/r/{rule_id}", timeout=(2, 30))
        response.raise_for_status()
        return str(response.text)
    except Exception as e:
        raise McpError(
            ErrorData(
                code=INTERNAL_ERROR, message=f"Error loading Semgrep rule schema: {e!s}"
            )
        ) from e


async def health(request: Request) -> JSONResponse:
    """Health check endpoint"""
    return JSONResponse({"status": "ok", "version": __VERSION__})


# ---------------------------------------------------------------------------------
# Disabling tools
# ---------------------------------------------------------------------------------

TOOL_DISABLE_ENV_VARS = {
    "SEMGREP_RULE_SCHEMA_DISABLED": "semgrep_rule_schema",
    "GET_SUPPORTED_LANGUAGES_DISABLED": "get_supported_languages",
    "SEMGREP_FINDINGS_DISABLED": "semgrep_findings",
    "SEMGREP_SCAN_WITH_CUSTOM_RULE_DISABLED": "semgrep_scan_with_custom_rule",
    "SEMGREP_SCAN_DISABLED": "semgrep_scan",
    "SEMGREP_SCAN_REMOTE_DISABLED": "semgrep_scan_remote",
    "GET_ABSTRACT_SYNTAX_TREE_DISABLED": "get_abstract_syntax_tree",
    "SEMGREP_SCAN_SUPPLY_CHAIN_DISABLED": "semgrep_scan_supply_chain",
}


def setup_oauth_routes(mcp: FastMCP, server_url: str) -> None:
    @mcp.custom_route("/.well-known/oauth-authorization-server", methods=["GET"])  # type: ignore
    async def oauth_authorization_server_route(request: Request) -> JSONResponse:
        metadata = get_oauth_authorization_server_metadata(get_semgrep_api_url())
        return JSONResponse(metadata)

    @mcp.custom_route("/.well-known/oauth-protected-resource", methods=["GET"])  # type: ignore
    async def oauth_protected_resource_route(request: Request) -> JSONResponse:
        authorization_server = get_authorization_server_url(get_semgrep_api_url())
        return JSONResponse(
            {
                "resource": f"{server_url}/mcp",
                "authorization_servers": [authorization_server],
                "scopes_supported": ["openid", "profile", "email", "offline_access"],
                "bearer_methods_supported": ["header"],
            }
        )


def register(mcp: FastMCP) -> None:
    state = get_state()
    # Since the remote server doesn't call the command semgrep mcp, which should
    # add the tag "(command/mcp)" to the user agent tag, we need to add the tag manually here
    # for it to show up in the metrics.
    if MCP_AGENT_TAG not in state.app_session.user_agent.tags:
        state.app_session.user_agent.tags.add(MCP_AGENT_TAG)

    # tools
    mcp.add_tool(semgrep_rule_schema)
    mcp.add_tool(get_supported_languages)
    mcp.add_tool(semgrep_findings)
    mcp.add_tool(semgrep_scan_with_custom_rule)
    mcp.add_tool(semgrep_scan)
    mcp.add_tool(semgrep_scan_remote)
    mcp.add_tool(get_abstract_syntax_tree)
    mcp.add_tool(semgrep_scan_supply_chain)
    mcp.add_tool(semgrep_whoami)

    # prompts
    mcp.add_prompt(Prompt.from_function(write_custom_semgrep_rule))
    mcp.add_prompt(Prompt.from_function(setup_semgrep_mcp))

    # resources
    mcp.add_resource(
        FunctionResource.from_function(
            uri="semgrep://rule/schema", fn=get_semgrep_rule_schema
        )
    )
    mcp.add_resource(
        FunctionResource.from_function(
            uri="semgrep://rule/{rule_id}/yaml", fn=get_semgrep_rule_yaml
        )
    )

    # custom routes
    # there's no API-level way to do this, so we inline it here
    mcp._custom_starlette_routes.append(
        Route(
            path="/health",
            endpoint=health,
            methods=["GET"],
        )
    )


def deregister_tools(mcp: FastMCP, transport: str) -> None:
    for env_var, tool_name in TOOL_DISABLE_ENV_VARS.items():
        is_disabled = os.environ.get(env_var, "false").lower() == "true"

        if is_disabled:
            # for the time being, while there is no way to API-level remove tools,
            # we'll just mutate the internal `_tools`, because this language does
            # not stop us from doing so
            if tool_name in mcp._tool_manager._tools:
                del mcp._tool_manager._tools[tool_name]

    if is_hosted():
        if "semgrep_scan" in mcp._tool_manager._tools:
            del mcp._tool_manager._tools["semgrep_scan"]
        if "semgrep_scan_supply_chain" in mcp._tool_manager._tools:
            del mcp._tool_manager._tools["semgrep_scan_supply_chain"]
    else:
        if "semgrep_scan_remote" in mcp._tool_manager._tools:
            del mcp._tool_manager._tools["semgrep_scan_remote"]

    if transport == "stdio":
        # The whoami tool doesn't work via stdio since it requires a JWT token,
        # which you can only get when connecting to the MCP server via streamable-http or sse
        # (which require OAuth).
        #
        # TODO?: if we implement OAuth for connecting to the MCP server locally,
        # we could enable it via stdio
        if "semgrep_whoami" in mcp._tool_manager._tools:
            del mcp._tool_manager._tools["semgrep_whoami"]
