# Análisis de Impacto de Anomalías - QZero

**Fecha:** 05/02/2026 03:40

## Resumen Ejecutivo

- Total de muestras analizadas: 21
- Calidad promedio: 60.7/100
- Ratio promedio de anomalías: 18.6%
- Última calidad: 70.0/100
- Tendencia: STABLE

## Recomendaciones

- **[HIGH]** Calidad promedio moderada (60-80)
