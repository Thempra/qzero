# QZero Semantic Analysis Report

**Generated:** 2026-02-03 02:07:25

## Summary

- Total anomalies: 5
- Unique types: 1
- High severity: 0 (0.0%)

## Anomaly Type Distribution

- unknown_pattern: 5

## Correlations and Patterns


## Recommendations

